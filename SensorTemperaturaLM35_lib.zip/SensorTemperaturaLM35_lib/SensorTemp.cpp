#include "SensorTemp.h"

SensorTemp::SensorTemp(int pin) {
  _pin = pin;
  pinMode(_pin, INPUT);
}

float SensorTemp::readTemperatureCelsius() {
  int rawValue = analogRead(_pin);
  float voltage = (rawValue / 1023.0) * 5.0;
  float temperatureC = (voltage - 0.5) * 100.0;
  return temperatureC;
}

float SensorTemp::readTemperatureFahrenheit() {
  float temperatureC = readTemperatureCelsius();
  float temperatureF = (temperatureC * 9.0 / 5.0) + 32.0; // Converte de Celsius para Fahrenheit
  return temperatureF;
}

float SensorTemp::readTemperatureKelvin() {
  float temperatureC = readTemperatureCelsius();
  float temperatureK = (temperatureC + 273.15); // Converte de Celsius para Kelvin
  return temperatureK;
}