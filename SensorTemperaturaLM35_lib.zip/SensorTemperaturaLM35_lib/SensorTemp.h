#ifndef SensorTemp_h
#define SensorTemp_h

#include <Arduino.h>

class SensorTemp {
public:
  SensorTemp(int pin);
  float readTemperatureCelsius(); // Função para ler em Celsius
  float readTemperatureFahrenheit(); // Função para ler em Fahrenheit
  float readTemperatureKelvin(); // Função para ler em Kelvin
  
private:
  int _pin;
};

#endif